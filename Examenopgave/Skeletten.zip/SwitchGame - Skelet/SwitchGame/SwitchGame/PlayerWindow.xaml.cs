﻿using SwitchGameData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SwitchGame
{
    /// <summary>
    /// Interaction logic for PlayerWindow.xaml
    /// </summary>
    public partial class PlayerWindow : Window
    {
        
        public PlayerWindow()
        {
            InitializeComponent();

            //TODO: haal alle spelers op en toon deze in de listbox
            //      maak gebruik van een ItemTemplate om de data van de spelers te tonen zoals in de opgave staat beschreven
            
        }

        private void playersListBox_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            // TODO: zorg dat de gekozen speler beschikbaar is in het MainWindow
        }
    }
}
