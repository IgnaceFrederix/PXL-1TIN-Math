﻿using SwitchGameData;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace SwitchGame
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {        
        
        public MainWindow()
        {
            InitializeComponent();
            // TODO: vul deze methode verder aan

            // TODO: 1. Zorg dat eerst het playerWindow wordt getoond, totdat er een speler werd gekozen. 
            //          Wanneer je geen speler kiest krijg je de melding: 'Choose a player, please' en wordt het playerWindow opnieuw getoond
            //       2. Wanneer er een speler werd gekozen, moeten de vragen van het juiste level worden geladen
            //       3. De eerste vraag + de keuzemogelijkheden moeten worden getoond + de image van de player komt boven de juiste positie te staan (code voor de image vind je hieronder)
            //       4. Wanneer de speler heeft geantwoord verschijnt na 1 seconde (code krijg je ook cadeau) de volgende vraag en dit tot alle vragen van het level zijn beantwoord

            
            // code om een image control op te vullen : 
            /* 
                            playerImage = new Image();
                            playerBitmap = new BitmapImage();
                            playerBitmap.BeginInit();                
                            playerBitmap.UriSource = new Uri(..., UriKind.Relative);
                            playerBitmap.EndInit();

                            pos5.Source = playerBitmap;
                            */
        }

        // Code die wordt uitgevoerd wannneer de speler op een antwoordbutton klikt

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            // TODO: controleer of de content op de button waarop werd geklikt, overeenkomt met het correcte antwoord
            //          indien juiste antwoord: background van button verandert naar groen - positie (foto) van speler verschuift 1 positie naar boven (links)
            //          indien foute antwoord: background van button verandert naar rood - positie (foto) van speler verspringt terug naar positie 5 
            //          de foto van de speler verschuift pas na 1 seconde + de volgende vraag verschijnt : zie code hieronder

            // ophalen van button waarop werd geklikt
            Button buttonClicked = (Button)sender;


            /*
             * code om na 1 seconde de foto van de speler te verschuiven + de volgende vraag te tonen
             * 
            var timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
            timer.Start();
            timer.Tick += (sender2, args) =>
            {
                timer.Stop();
                
                TODO: verschuif positie van de speler
                        haal de volgende vraag op (als er nog vragen zijn / als positie nog niet 1 is)
                
            };
            
        */
        }



        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            this.MinWidth = this.ActualWidth;
            this.MinHeight = this.ActualHeight;
            this.MaxHeight = this.ActualHeight;
        }

        private void LoadQuestion()
        {
            /*TODO: gebruik deze methode om de volgende vraag + de mogelijke antwoorden te tonen
             * */
      
        }


        // Deze methode kan je gebruiken om een lijst van buttons op te halen binnen je window 
        // zodat je een loop kan schrijven om voor alle buttons het antwoord op te button te plaatsen
        // of om de achtergrondkleur van alle buttons in te stellen
        // Gebruik deze methode als volgt: GetLogicalChildCollection(this, buttonList);
        // buttonList declareer je eerst als een lijst van Buttons List<Button> buttonList
        // Je kan dan over de lijst van buttons itereren om bv de Content op de BackGround property in te stellen

        private static void GetLogicalChildCollection<T>(DependencyObject parent, List<T> logicalCollection) where T : DependencyObject
        {
            IEnumerable children = LogicalTreeHelper.GetChildren(parent);
            foreach (object child in children)
            {
                if (child is DependencyObject)
                {
                    DependencyObject depChild = child as DependencyObject;
                    if (child is T)
                    {
                        logicalCollection.Add(child as T);
                    }

                    GetLogicalChildCollection(depChild, logicalCollection);
                }
            }
        }
    }
}
