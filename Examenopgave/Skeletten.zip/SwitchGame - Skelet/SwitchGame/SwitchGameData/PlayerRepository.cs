﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwitchGameData
{
    public class PlayerRepository
    {
        /*
        public ... GetPlayers()
        {
            TODO: vervolledig deze methode
        }
        */

        /*
        public ... UpdatePlayerLevel(int playerId, int level)
        {
            TODO: vervolledig deze methode 
        }
        */
    }
}
