﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwitchGameData
{
    public static class AnswerRepository
    {
        /*
        public ... GetAnswers(int questionId)
        {            
        
        TODO: vervolledig deze methode  
          
        }
        */
    }
}
