﻿using Microsoft.Win32;
using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace TodoBoard
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private const int MaxTodoitems = 10;
        private ObservableCollection<IToDoItem> _toDoItems;

        public MainWindow()
        {
            InitializeComponent();

            workloadBar.Maximum = MaxTodoitems;
            workloadBar.Value = 0;

            _toDoItems = new ObservableCollection<IToDoItem>();
            toDoListBox.ItemsSource = _toDoItems;
        }

        #region Do not change

        private void comboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (!taskTypeComboBox.IsLoaded) return; //ensure all controls are loaded before setting visibility of those controls

            switch (taskTypeComboBox.SelectedIndex)
            {
                case 0:
                    showTaskControls();
                    break;
                case 1:
                    showReminderControls();
                    break;
            }
        }

        private void showTaskControls()
        {
            durationLabel.Visibility = Visibility.Visible;
            durationTextBox.Visibility = Visibility.Visible;
        }

        private void showReminderControls()
        {
            durationLabel.Visibility = Visibility.Hidden;
            durationTextBox.Visibility = Visibility.Hidden;
        }

        #endregion

        private void addButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                switch (taskTypeComboBox.SelectedIndex)
                {
                    case 0:
                        var task = new Task(descriptionTextBox.Text, durationTextBox.Text);
                        AddToDoItem(task);
                        break;
                    case 1:
                        var reminder = new Reminder(descriptionTextBox.Text);
                        AddToDoItem(reminder);
                        break;
                }
                clearTextBoxes();
            }
            catch (InvalidDurationException ex)
            {
                MessageBox.Show(string.Concat("Ongeldige duur. ", ex.Message));
            }
        }

        private void clearTextBoxes()
        {
            durationTextBox.Text = "";
            descriptionTextBox.Text = "";
        }

        private void clearToDoItems()
        {
            _toDoItems.Clear();
            workloadBar.Value = 0;
        }

        private void clearButton_Click(object sender, RoutedEventArgs e)
        {
            clearToDoItems();
        }

       

        private void AddToDoItem(IToDoItem item)
        {
            if (_toDoItems.Count < MaxTodoitems)
            {
                _toDoItems.Add(item);

                workloadBar.Value = _toDoItems.Count;
            }
            else
            {
                MessageBox.Show("Maximale werkbelasting bereikt.");
            }
        }

      

        private void ExitMenuItem_Click(object sender, RoutedEventArgs e)
        {
            Environment.Exit(0);
        }
    }
}
