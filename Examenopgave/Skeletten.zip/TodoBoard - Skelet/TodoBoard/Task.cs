﻿using System;

namespace TodoBoard
{
    public class Task : IToDoItem
    {
        public string Description { get; set; }

        public TimeSpan Duration { get; set; }

        public string DisplayText
        {
            get
            {
                return $"{Description} - {Duration.Hours} uren {Duration.Minutes} minuten";
            }
        }

        public Task(string description, string duration)
        {
            Description = description;

            Duration = ParseDuration(duration);
        }

        public string Serialize()
        {
            return string.Concat("Task:", Description, "|", Duration.Hours, ":", Duration.Minutes);
        }

        /// <summary>
        /// Takes a duration in a string format and parses it to a TimeSpan
        /// </summary>
        /// <param name="input">Duration in a string format. Should be 'hh:mm' (hours and minutes) or 'hh' (hours).</param>
        /// <returns>The parsed duration timespan</returns>
        /// <exception cref="InvalidDurationException">
        /// Thrown when the supplied duration is empty or invalid.
        /// </exception>
        private TimeSpan ParseDuration(string input)
        {
            if (string.IsNullOrEmpty(input))
            {
                throw new InvalidDurationException("Geen duur ingevuld.");
            }

            var parts = input.Split(new char[] { ':' });

            if (parts.Length != 2)
            {
                throw new InvalidDurationException("De input string moet exact 1 dubbelpunt bevatten.");
            }

            var hours = 0;
            var minutes = 0;
            try
            {
                hours = Convert.ToInt32(parts[0]);

                if (parts.Length == 2)
                {
                    minutes = Convert.ToInt32(parts[1]);
                }
            }
            catch (FormatException)
            {
                throw new InvalidDurationException("De uren en minuten moeten uit cijfers bestaan."); 
            }

            if (hours >= 24) throw new InvalidDurationException("Het aantal uren kan niet hoger als 23 zijn."); 
            if (minutes >= 60) throw new InvalidDurationException("Het aantal minuten kan niet hoger als 59 zijn."); 

            return new TimeSpan(hours, minutes, 0);
        }
    }
}
