﻿using System;

namespace TodoBoard
{
    public class Reminder : IToDoItem
    {
        public string Description { get; set; }

        public string DisplayText
        {
            get{ return Description; }
        }

        public Reminder(string description)
        {
            Description = description;
        }

        public string Serialize()
        {
            return string.Concat("Reminder:", Description);
        }
    }
}
