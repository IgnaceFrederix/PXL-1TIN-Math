﻿namespace TodoBoard
{
    public interface IToDoItem
    {
        /// <summary>
        /// Text to be displayed in ToDo lists on the screen
        /// </summary>
        string DisplayText { get; }

        /// <summary>
        /// Serializes the ToDo item to a string so it can be saved to a file.
        /// </summary>
        /// <returns>String representation of the ToDo item</returns>
        string Serialize();
    }
}
