﻿using System;

namespace TodoBoard
{
    public class InvalidDurationException : ApplicationException
    {
        public InvalidDurationException(string message) : base(message)
        {
        }
    }
}