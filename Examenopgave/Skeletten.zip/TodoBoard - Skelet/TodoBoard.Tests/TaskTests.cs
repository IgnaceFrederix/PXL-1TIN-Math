﻿using System;
using System.Reflection;
using NUnit.Framework;

namespace TodoBoard.Tests
{
    [TestFixture]
    internal class TaskTests 
    {        
        [Test]
        [TestCase("00:00", "0 uren 0 minuten")]
        [TestCase("11:20", "11 uren 20 minuten")]
        [TestCase("1:20", "1 uren 20 minuten")]
        [TestCase("01:01", "1 uren 1 minuten")]
        [TestCase("2:5", "2 uren 5 minuten")]
        public void ReturnsValidDisplayText(string durationText, string expectedTimestring)
        {
            // TODO: vul deze test aan
        }

        [Test]
        [TestCase("00:00", "0:0")]
        [TestCase("11:20", "11:20")]
        [TestCase("1:20", "1:20")]
        [TestCase("01:01", "1:1")]
        [TestCase("2:5", "2:5")]
        public void SerializesCorrectly(string durationText, string expectedTimestring)
        {
            // TODO: Vul deze test aan
        }

        [Test]
        [TestCase(null)]
        [TestCase("")]
        public void EmptyDurationTextCausesInvalidDurationException(string emptyString)
        {
            // TODO: Vul deze test aan
        }

        [Test]
        public void DurationTextWithMultipleColonsCausesInvalidDurationException()
        {
            // TODO: Vul deze test aan
        }

        [Test]
        [TestCase("1u:2m")]
        [TestCase("tien:tien")]
        public void DurationTextWithInvalidCharactersCausesInvalidDurationException(string invalidDurationText)
        {
            // TODO: Vul deze test aan
        }

        [Test]
        [TestCase("24:00")]
        [TestCase("50:10")]
        public void DurationTextWithTooManyHoursCausesInvalidDurationException(string invalidDurationText)
        {
            // TODO: Vul deze test aan
        }

        [Test]
        [TestCase("0:60")]
        [TestCase("10:890")]
        public void DurationTextWithTooManyMinutesCausesInvalidDurationException(string invalidDurationText)
        {
            // TODO: Vul deze test aan
        }
    }
}
