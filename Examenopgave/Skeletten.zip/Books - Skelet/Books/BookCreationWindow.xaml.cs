﻿using Books.Domainclasses;
using Books.Repositories;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Books
{
    /// <summary>
    /// Interaction logic for BookCreationWindow.xaml
    /// </summary>
    public partial class BookCreationWindow : Window
    {

        public BookCreationWindow(BookRepository repo, MainWindow mainWindow = null)
        {
            InitializeComponent();
            //TODO: vul aan
        }

        private void AddBook(object sender, RoutedEventArgs e)
        {
            //TODO: vul aan
        }

        private void AddCharacter(object sender, RoutedEventArgs e)
        {
            // TODO: vul aan
        }
    }
}
