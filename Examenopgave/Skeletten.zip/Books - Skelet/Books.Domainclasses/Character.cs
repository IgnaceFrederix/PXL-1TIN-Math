﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Books.Domainclasses
{
    public class Character
    {
       //TODO: Vul deze klasse aan
    }
}
