﻿using Books.Datalayer;
using Books.Domainclasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Books.Repositories
{
    public class BookRepository
    {
        
        /*
         * TODO: Vul de nodige methodes aan
         * 
        public BookRepository()
        {
            
        }

        public List<Book> GetAllBooks()
        {
            
        }

        public Book GetBookWithISBN(string ISBN)
        {
            
        }

        public Author GetAuthorOfBook(string ISBN)
        {
            
        }

        public List<Character> GetAllCharactersInBook(string ISBN)
        {
            
        }

        public List<Author> GetAllAuthors()
        {
            
        }

        public List<Genre> GetAllGenres()
        {
            
        }
        public List<Character> GetAllCharacters()
        {
            
        }

        public void AddBook(Book book)
        {
            
        }
        */
    }
}
